import React from "react";
import './postcard.css';
import Like from './pics/heart (2).png';

function Postcard(){
    function changeColor() {
        
      }
    

return(

    <div className="postcard">
        <div className="ppf"><div className="profile"></div><p className="name">Name</p></div>
         <div className="posting"></div>
         <div className="likebutton"><button onClick={changeColor}><img src={Like} alt=''></img></button></div>
         <p style={{fontSize:'15px', marginTop:"0px"}}>Nameofuser</p>
    </div>
);



}
export default Postcard;