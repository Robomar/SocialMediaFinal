import React from "react";
import './menubar.css';
import Hpic from './pics/home.png';
import Profpic from './pics/user.png';
import Notipic from './pics/bell.png';
import Postpic from './pics/more.png';
import Settpic from './pics/settings.png';
import Logout from './pics/logout.png';
import Logo from './pics/logo.png';

function Menubar(){
    return(

     <div className='menu'>
      <img className="sociable" src={Logo} alt=""></img><h2>Sociable</h2>
      <div>
      <div className="homebar"><img src={Hpic} alt=""></img><h3 >Home</h3></div>

      <div><img src={Profpic} alt=""></img><h3>Profile</h3> </div>

      <div><img src={Postpic}></img><h3>Post</h3></div>

      <div><img src={Notipic}></img> <h3>Notifications</h3></div>

      <div><img src={Settpic}></img><h3>Settings</h3></div>

      <div className="logout"><img src={Logout}></img><h3 >Logout</h3></div>
      </div>
    

     </div>
     );
     }
     export default Menubar;