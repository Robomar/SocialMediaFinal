import React from "react";
function Profile(){
return(
    <div style={{margin:'5px' , display:"flex", flexDirection: "row"}}>
        <div className="pfp" style={{height:'30px', width:'30px', borderRadius:'50%', background: "gray", marginRight:'5px'}}></div>
        <p style={{marginTop:"5px"}}>Name</p>
    </div>


);
}
export default Profile; 